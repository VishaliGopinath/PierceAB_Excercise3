package PierceAB;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class TS02_ViewProduct {

	public static void main(String[] args) {

				try {
					System.setProperty("webdriver.chrome.driver","D:\\Manual Testing\\chromedriver_win32\\chromedriver.exe");
					WebDriver driver = new ChromeDriver();
					driver.manage().window().maximize();
					driver.manage().deleteAllCookies();
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));			
					
					driver.get("http://automationpractice.com/index.php");
					WebElement ProductTab=driver.findElement(By.cssSelector("a[title='Women']"));
					ProductTab.click();
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
					WebElement ViewProduct=driver.findElement(By.partialLinkText("Printed Dre"));
					ViewProduct.click();
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
					WebElement Results=driver.findElement(By.cssSelector("div[id='short_description_content'] p"));	
					String ActualResult = Results.getText();
					if(ActualResult.contains("rinted dress"))
						System.out.println("Test Case Passed - Able to view Product!");	
					else
						System.out.println("Test Case Failed - Not able to view Product!");	
					
					driver.quit();
				} catch (Exception e) {
					
					e.printStackTrace();
				}
					}
}
