package PierceAB;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TS01_SearchProduct {

	public static void main(String[] args) {

		try {
			System.setProperty("webdriver.chrome.driver","D:\\Manual Testing\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));	
			
			driver.get("http://automationpractice.com/index.php");
			WebElement Product=driver.findElement(By.id("search_query_top"));
			Product.sendKeys("Blouse");
			WebElement Search=driver.findElement(By.name("submit_search"));
			Search.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
			WebElement Results=driver.findElement(By.cssSelector(".heading-counter"));		
			String SearchResult = Results.getText();
			if(SearchResult.contains("result has been found"))
				System.out.println("Test Case Passed - Product Found!");	
			else
				System.out.println("Test Case Failed - Product Not Found!");	
						
			driver.quit();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
				

	}

}
