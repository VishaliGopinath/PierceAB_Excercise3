package PierceAB;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TS03_DeleteProductFromCart {

	public static void main(String[] args) {
		
		try {
			System.setProperty("webdriver.chrome.driver","D:\\Manual Testing\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));	
			
			driver.get("http://automationpractice.com/index.php");					
			Actions actions=new Actions(driver);
			WebElement Product=driver.findElement(By.partialLinkText("shirts"));
			actions.moveToElement(Product).perform();
			WebElement AddProduct=driver.findElement(By.xpath("(//a[@title='Add to cart'])[1]"));
			AddProduct.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			WebElement GoToCart=driver.findElement(By.cssSelector("a[title='Proceed to checkout'] span"));
			GoToCart.click();
			driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(3));
			WebElement DeleteProduct=driver.findElement(By.className("cart_quantity_delete"));
			DeleteProduct.click();
			Thread.sleep(5000);
			WebElement Results=driver.findElement(By.cssSelector(".alert.alert-warning"));	
			String ActualResult = Results.getText();
			if(ActualResult.contains("empty"))
				System.out.println("Test Case Passed - Product Deleted!");	
			else
				System.out.println("Test Case Failed - Issue in deleting Product!");	
			
			driver.quit();
			
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	

	}

}
